Código y datos de reproducibilidad — Informe 2 (Búsqueda Tabú con reinicio para el MCP)
=========================================================================================

Estructura (idéntica a las rutas citadas en informe2.pdf, Apéndice y Sección "Contraste de
Resultados"):

notebook_metaheuristica/
    mcp_tabu_ils.py            Algoritmo (Búsqueda Tabú + reinicio ILS-like)
    run_experiments.py         30 corridas independientes por instancia (keller4, C125.9);
                                genera runs_*.json, results_summary.json y las figuras
                                de convergencia / clique / comparación de tiempos.
    run_ablation.py            Experimento de ablación (mecanismo de reinicio desactivado);
                                genera ablation_sin_reinicio.json.
    keller4.clq, C125.9.clq    Instancias DIMACS.
    runs_keller4.json,
    runs_C125.9.json,
    results_summary.json,
    ablation_sin_reinicio.json Salidas ya generadas (las usadas en el informe).
    *.png                      Figuras ya generadas (las incluidas en el informe).

notebook/
    maximum_clique_bb.ipynb    Branch & Bound manual (PyBnB) sobre C125.9, referenciado en
                                la Sección "Contraste de Resultados" del informe2.
    C125.9.clq                 Copia local de la instancia (por defecto el notebook la
                                descarga de una URL vía la variable INSTANCE_SOURCE; para
                                correrlo sin conexión, cambiar esa variable a
                                'C125.9.clq').

Cómo reproducir
----------------
Requiere Python 3.9+, numpy, matplotlib, networkx (para notebook_metaheuristica/) y
además jupyter, pandas, scipy, pybnb (para notebook/maximum_clique_bb.ipynb).

1. cd notebook_metaheuristica
   python run_experiments.py     # reproduce runs_*.json, results_summary.json, figuras
   python run_ablation.py        # reproduce ablation_sin_reinicio.json

2. jupyter notebook notebook/maximum_clique_bb.ipynb
   (ejecutar todas las celdas; usa la instancia C125.9)

Los archivos de salida ya están incluidos tal como se usaron para escribir el informe, de
modo que no es necesario volver a ejecutar nada para verificar los números reportados.
